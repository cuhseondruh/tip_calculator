Built the executable with the commands

`cd \\wsl.localhost\Ubuntu\home\cas\design_build\tip_calculator`

`poetry run flet build windows \\wsl.localhost\Ubuntu\home\cas\design_build\tip_calculator --output \\wsl.localhost\Ubuntu\home\cas\design_build\tip_calculator\output`